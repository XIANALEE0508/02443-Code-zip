using Random
using Statistics

# Define parameter list
params = [
    (a = 1664525, c = 10139, M = 562490),
    (a = 1103515245, c = 12345, M = 25453),
    (a = 134775813, c = 1, M = 42342),
    (a = 69069, c = 6, M = 247895),
    (a = 48271, c = 1, M = 868574),
    (a = 2147483629, c = 2147483587, M = 242342),
    (a = 16807, c = 5, M = 23424),
    (a = 1680732, c = 87, M = 23423289),
    (a = 74293826685, c = 78, M = 235342),
    (a = 22695477, c = 9, M = 79898)
]

# Seed
x0 = 12345

# LCG Random number generator
function LCG(n, seed, a, c, M)
    x = zeros(Float64, n)
    x[1] = seed
    for i in 2:n
        x[i] = (a * x[i-1] + c) % M
    end
    return x / M
end

# Number of random numbers
n = 1000

# Function to calculate number of runs
function count_runs(seq)
    runs = 1
    for i in 2:length(seq)
        if seq[i] != seq[i-1]
            runs += 1
        end
    end
    return runs
end

# Function to perform runs test
function runs_test(seq)
    n1 = count(x -> x, seq) # number of True (above median)
    n2 = count(x -> !x, seq) # number of False (below median)
    n = n1 + n2
    runs = count_runs(seq)
    
    mean_runs = (2 * n1 * n2) / n + 1
    var_runs = (2 * n1 * n2 * (2 * n1 * n2 - n1 - n2)) / ((n^2) * (n - 1))
    z = (runs - mean_runs) / sqrt(var_runs)
    
    return (runs = runs, z = z, p_value = 2 * (1 - cdf(Normal(), abs(z))))
end

# Perform Wald-Wolfowitz runs test
for i in 1:length(params)
    param = params[i]
    random_numbers = LCG(n, x0, param.a, param.c, param.M)

    # Calculate the median
    median_value = median(random_numbers)

    # Create a sequence of above/below median
    above_below = random_numbers .> median_value

    # Perform runs test
    result = runs_test(above_below)

    println("Wald-Wolfowitz Runs Test for LCG with parameters set $i:")
    println("Number of runs: ", result.runs, ", Z value: ", result.z, ", p-value: ", result.p_value)
    println()
end
