using Random
using Statistics
using Distributions

# Define parameter list
params = [
    (a = 1664525, c = 10139, M = 562490),
    (a = 1103515245, c = 12345, M = 25453),
    (a = 134775813, c = 1, M = 42342),
    (a = 69069, c = 6, M = 247895),
    (a = 48271, c = 1, M = 868574),
    (a = 2147483629, c = 2147483587, M = 242342),
    (a = 16807, c = 5, M = 23424),
    (a = 1680732, c = 87, M = 23423289),
    (a = 74293826685, c = 78, M = 235342),
    (a = 22695477, c = 9, M = 79898)
]

# Seed
x0 = 12345

# LCG Random number generator
function LCG(n, seed, a, c, M)
    x = zeros(Float64, n)
    x[1] = seed
    for i in 2:n
        x[i] = (a * x[i-1] + c) % M
    end
    return x / M
end

# Number of random numbers
n = 5000

# Function to perform Kolmogorov-Smirnov test
function ks_test(seq)
    n = length(seq)
    sorted_seq = sort(seq)
    
    # Calculate the D+ and D- statistics
    D_plus = maximum(((i / n) - sorted_seq[i]) for i in 1:n)
    D_minus = maximum((sorted_seq[i] - ((i - 1) / n)) for i in 1:n)
    
    # Kolmogorov-Smirnov statistic
    D = max(D_plus, D_minus)
    
    # Calculate p-value using the asymptotic formula for large n
    p_value = 1 - kolmogorov_smirnov_cdf(D, n)
    
    return (D = D, p_value = p_value)
end

# Kolmogorov-Smirnov CDF approximation
function kolmogorov_smirnov_cdf(D, n)
    if D == 0
        return 0.0
    end
    K = (sqrt(n) + 0.12 + 0.11 / sqrt(n)) * D
    return 2 * sum((-1)^(k-1) * exp(-2 * k^2 * K^2) for k in 1:100)
end

# Perform Kolmogorov-Smirnov test
for i in 1:length(params)
    param = params[i]
    random_numbers = LCG(n, x0, param.a, param.c, param.M)
    
    result = ks_test(random_numbers)
    
    println("Kolmogorov-Smirnov Test for LCG with parameters set $i:")
    println("D value: ", result.D, ", p-value: ", result.p_value)
    println()
end

