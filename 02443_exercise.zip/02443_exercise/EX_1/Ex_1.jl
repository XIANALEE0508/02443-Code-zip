using Conda
Conda.add("matplotlib")
Conda.add("scipy")

using PyCall
np = pyimport("numpy")
plt = pyimport("matplotlib.pyplot")
chisquare = pyimport("scipy.stats").chisquare

# Define parameter list
params = [
    Dict("a" => 1664525, "c" => 10139, "M" => 562490),
    Dict("a" => 1103515245, "c" => 12345, "M" => 25453),
    Dict("a" => 134775813, "c" => 1, "M" => 42342),
    Dict("a" => 69069, "c" => 6, "M" => 247895),
    Dict("a" => 48271, "c" => 1, "M" => 868574),
    Dict("a" => 2147483629, "c" => 2147483587, "M" => 242342),
    Dict("a" => 16807, "c" => 5, "M" => 23424),
    Dict("a" => 1680732, "c" => 87, "M" => 23423289),
    Dict("a" => 74293826685, "c" => 78, "M" => 235342),
    Dict("a" => 22695477, "c" => 9, "M" => 79898)
]

# seed
x0 = 12345

# LCG Random number generator
function LCG(n, seed, a, c, M)
    x = np.zeros(n)
    x[1] = seed
    for i in 2:n
        x[i] = (a * x[i-1] + c) % M
    end
    return x / M
end

# number
n = 10000

# Plot
fig, ax_arr = plt.subplots(5, 4, figsize=(15, 20))
ax_arr = reshape(ax_arr, :)

for i in 1:10
    param = params[i]
    random_numbers = LCG(n, x0, param["a"], param["c"], param["M"])

    # histogram
    ax = ax_arr[2 * (i-1) + 1]
    ax.hist(random_numbers, bins=50, color="blue")
    ax.set_title("Histogram $i")

    # Scatter plot
    ax = ax_arr[2 * (i-1) + 2]
    ax.scatter(random_numbers[1:end-1], random_numbers[2:end], color="blue", s=1)
    ax.set_title("Scatter Plot $i")
end

plt.tight_layout()
plt.show()

# Chi-Square Test
num_bins = 10

for i in 1:10
    param = params[i]
    random_numbers = LCG(n, x0, param["a"], param["c"], param["M"])

    # Chi-Square Test
    observed, _ = np.histogram(random_numbers, bins=num_bins)
    expected = np.full(num_bins, n / num_bins)
    chi_square_test = chisquare(observed, expected)

    println("Chi-Square Test for LCG with parameters set $i:")
    println(chi_square_test)
    println()
end
