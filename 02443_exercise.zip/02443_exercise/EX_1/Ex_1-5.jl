using Random
using Statistics
using Distributions

# Define parameter list
params = [
    (a = 1664525, c = 10139, M = 562490),
    (a = 1103515245, c = 12345, M = 25453),
    (a = 134775813, c = 1, M = 42342),
    (a = 69069, c = 6, M = 247895),
    (a = 48271, c = 1, M = 868574),
    (a = 2147483629, c = 2147483587, M = 242342),
    (a = 16807, c = 5, M = 23424),
    (a = 1680732, c = 87, M = 23423289),
    (a = 74293826685, c = 78, M = 235342),
    (a = 22695477, c = 9, M = 79898)
]

# Seed
x0 = 12345

# LCG Random number generator
function LCG(n, seed, a, c, M)
    x = zeros(Float64, n)
    x[1] = seed
    for i in 2:n
        x[i] = (a * x[i-1] + c) % M
    end
    return x / M
end

# Number of random numbers
n = 5000
h = 1  # lag

# Function to calculate correlation
function correlation_test(seq, h)
    n = length(seq)
    ch = mean(seq[1:n-h] .* seq[h+1:n])
    expected_mean = 0.25
    expected_var = 7 / (144 * n)
    z = (ch - expected_mean) / sqrt(expected_var)
    p_value = 2 * (1 - cdf(Normal(), abs(z)))
    return (ch = ch, z = z, p_value = p_value)
end

# Perform correlation test
for i in 1:length(params)
    param = params[i]
    random_numbers = LCG(n, x0, param.a, param.c, param.M)
    
    result = correlation_test(random_numbers, h)
    
    println("Correlation Test for LCG with parameters set $i:")
    println("ch value: ", result.ch, ", Z value: ", result.z, ", p-value: ", result.p_value)
    println()
end
