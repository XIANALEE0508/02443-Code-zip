using LinearAlgebra
using Statistics
using Random
using Distributions

# Define parameter list
params = [
    (a = 1664525, c = 10139, M = 562490),
    (a = 1103515245, c = 12345, M = 25453),
    (a = 134775813, c = 1, M = 42342),
    (a = 69069, c = 6, M = 247895),
    (a = 48271, c = 1, M = 868574),
    (a = 2147483629, c = 2147483587, M = 242342),
    (a = 16807, c = 5, M = 23424),
    (a = 1680732, c = 87, M = 23423289),
    (a = 74293826685, c = 78, M = 235342),
    (a = 22695477, c = 9, M = 79898)
]

# Seed
x0 = 12345

# LCG Random number generator
function LCG(n, seed, a, c, M)
    x = zeros(Float64, n)
    x[1] = seed
    for i in 2:n
        x[i] = (a * x[i-1] + c) % M
    end
    return x / M
end

# Number of random numbers
n = 5000

# Function to calculate run lengths
function run_lengths(seq)
    lengths = []
    current_run_length = 1

    for i in 2:length(seq)
        if seq[i] > seq[i-1]
            if current_run_length > 0
                current_run_length += 1
            else
                push!(lengths, abs(current_run_length))
                current_run_length = 1
            end
        elseif seq[i] < seq[i-1]
            if current_run_length < 0
                current_run_length -= 1
            else
                push!(lengths, current_run_length)
                current_run_length = -1
            end
        end
    end
    push!(lengths, abs(current_run_length))
    return lengths
end

# Function to perform The-Up-and-Down Test
function up_and_down_test(seq)
    run_lens = run_lengths(seq)
    run_counts = Dict{Int, Int}()
    
    for len in run_lens
        if haskey(run_counts, len)
            run_counts[len] += 1
        else
            run_counts[len] = 1
        end
    end
    
    expected_counts = Dict{Int, Float64}()
    
    for k in keys(run_counts)
        if k == 1
            expected_counts[k] = (n + 1) / 12
        elseif k == 2
            expected_counts[k] = (11 * n - 4) / 12
        else
            expected_counts[k] = 2 * ((k^2 + 3 * k + 1) * n - (k^3 + 3 * k^2 - k - 4)) / factorial(k + 3)
        end
    end

    X = sum(values(run_counts))
    mean_X = (2 * n - 1) / 3
    var_X = sqrt(16 * n - 29) / 90

    Z = (X - mean_X) / var_X

    return (X = X, Z = Z, p_value = 2 * (1 - cdf(Normal(0, 1), abs(Z))))
end

# Perform The-Up-and-Down Test
for i in 1:length(params)
    param = params[i]
    random_numbers = LCG(n, x0, param.a, param.c, param.M)
    
    result = up_and_down_test(random_numbers)
    
    println("The-Up-and-Down Test for LCG with parameters set $i:")
    println("X value: ", result.X, ", Z value: ", result.Z, ", p-value: ", result.p_value)
    println()
end
