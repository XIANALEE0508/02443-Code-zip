using Distributions
using Plots

# 定义参数 p
p = 0.4

# 几何分布
geom_dist = Geometric(p)

# 模拟 10,000 个结果
n = 10000
simulated_data = rand(geom_dist, n)

# 显示模拟结果的直方图
histogram(simulated_data, bins=30, xlabel="Number of Trials", ylabel="Frequency", title="Geometric Distribution (p=0.4)", legend=false)
