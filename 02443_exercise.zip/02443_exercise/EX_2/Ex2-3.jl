using Random
using StatsBase

# 定义X和对应的概率
X = [1, 2, 3, 4, 5, 6]
p = [7/48, 5/48, 1/8, 1/16, 1/4, 5/16]
k = length(X)
c = 0.1875  # 给定的c值

# 构建Alias表
function alias_setup(p)
    k = length(p)
    L = collect(1:k)
    F = k .* p
    
    G = findall(x -> x >= 1, F)
    S = findall(x -> x < 1, F)
    
    while !isempty(S)
        i = G[1]
        j = S[1]
        
        L[j] = i
        F[i] = F[i] - (1 - F[j])
        
        if F[i] < 1 - eps()
            push!(S, i)
            deleteat!(G, 1)
        end
        deleteat!(S, 1)
    end
    
    return F, L
end

F, L = alias_setup(p)
# Print the Alias table L
println("Alias table L: ", L)
# 使用Alias Method生成随机数
function alias_draw(F, L, X, n)
    k = length(X)
    U1 = rand(n)
    U2 = rand(n)
    I = floor.(Int, k .* U1) .+ 1
    X_generated = similar(U1)
    
    for idx in 1:n
        i = I[idx]
        if U2[idx] <= F[i]
            X_generated[idx] = X[i]
        else
            X_generated[idx] = X[L[i]]
        end
    end
    
    return X_generated
end

# 生成随机数
n = 10000
X_generated = alias_draw(F, L, X, n)

# 显示生成结果的直方图
histogram(X_generated, bins=length(X), xticks=X, xlabel="X", ylabel="Frequency", title="Generated X using Alias Method", legend=false)
