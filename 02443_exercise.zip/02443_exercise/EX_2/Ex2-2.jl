using Random
using StatsBase

# 定义X和对应的概率
X = [1, 2, 3, 4, 5, 6]
p = [7/48, 5/48, 1/8, 1/16, 1/4, 5/16]

# 计算累积概率分布
cumulative_p = cumsum(p)

# 生成[0, 1]范围内的随机数
n = 10000
U = rand(n)

# 使用直接方法生成X
function generate_X(U, X, cumulative_p)
    X_generated = similar(U)
    for i in 1:length(U)
        for j in 1:length(X)
            if U[i] <= cumulative_p[j]
                X_generated[i] = X[j]
                break
            end
        end
    end
    return X_generated
end

X_generated = generate_X(U, X, cumulative_p)

# 显示生成结果的直方图
histogram(X_generated, bins=length(X), xticks=X, xlabel="X", ylabel="Frequency", title="Generated X from Discrete Distribution", legend=false)
