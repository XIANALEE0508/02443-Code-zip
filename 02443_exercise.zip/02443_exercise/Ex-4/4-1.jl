using Random, Distributions, Printf, Statistics

function simulate_blocking_system(seed::Int, m::Int, mean_service_time::Float64, mean_interarrival_time::Float64, total_customers::Int)
    Random.seed!(seed)

    # Calculate rates
    arrival_rate = 1 / mean_interarrival_time
    service_rate = 1 / mean_service_time

    # Simulate arrival times and service times
    arrival_times = cumsum(rand(Exponential(arrival_rate), total_customers))
    service_times = rand(Exponential(service_rate), total_customers)

    # Initialize service units
    servers = zeros(m)
    blocked_customers = 0  # Number of blocked customers

    # Simulation process
    for i in 1:total_customers
        # Check if there is an available service unit
        available_server = argmin(servers)
        if servers[available_server] <= arrival_times[i]
            # If there is an available service unit, assign it to the customer
            servers[available_server] = arrival_times[i] + service_times[i]
        else
            # If there is no available service unit, the customer is blocked
            blocked_customers += 1
        end
    end

    # Calculate blocking rate
    blocking_fraction = blocked_customers / total_customers

    # Calculate confidence interval
    alpha = 0.05
    z = quantile(Normal(0, 1), 1 - alpha / 2)
    conf_interval = blocking_fraction .+ [-1, 1] * z * sqrt(blocking_fraction * (1 - blocking_fraction) / total_customers)

    # Output results
    @printf("Number of blocked customers: %d\n", blocked_customers)
    @printf("Blocking fraction: %.5f\n", blocking_fraction)
    @printf("95%% confidence interval: [%.5f, %.5f]\n", conf_interval...)
end

# Parameters from the problem statement
m = 10  # Number of service units
mean_service_time = 8.0  # Mean service time
mean_interarrival_time = 1.0  # Mean inter-arrival time
total_customers = 100000  # Total number of customers

# Run the simulation with given parameters
simulate_blocking_system(123, m, mean_service_time, mean_interarrival_time, total_customers)
