using Random, Distributions, Printf, Statistics

function simulate_blocking_system_constant(seed::Int, m::Int, service_time::Float64, total_customers::Int)
    Random.seed!(seed)

    # Calculate rates
    arrival_rate = 1.0  # Mean interarrival time = 1
    service_rate = 1 / service_time  # Service rate

    # Simulate arrival times
    arrival_times = cumsum(rand(Exponential(arrival_rate), total_customers))
    service_times = fill(service_time, total_customers)  # Constant service time

    # Initialize service units
    servers = zeros(m)
    blocked_customers = 0  # Number of blocked customers

    # Simulation process
    for i in 1:total_customers
        # Check if there is an available service unit
        available_server = argmin(servers)
        if servers[available_server] <= arrival_times[i]
            # If there is an available service unit, assign it to the customer
            servers[available_server] = arrival_times[i] + service_times[i]
        else
            # If there is no available service unit, the customer is blocked
            blocked_customers += 1
        end
    end

    # Calculate blocking rate
    blocking_fraction = blocked_customers / total_customers

    # Calculate confidence interval
    alpha = 0.05
    z = quantile(Normal(0, 1), 1 - alpha / 2)
    conf_interval = blocking_fraction .+ [-1, 1] * z * sqrt(blocking_fraction * (1 - blocking_fraction) / total_customers)

    # Output results
    @printf("Constant Service Time\n")
    @printf("Number of blocked customers: %d\n", blocked_customers)
    @printf("Blocking fraction: %.5f\n", blocking_fraction)
    @printf("95%% confidence interval: [%.5f, %.5f]\n", conf_interval...)
end

simulate_blocking_system_constant(123, 10, 8.0, 100000)
