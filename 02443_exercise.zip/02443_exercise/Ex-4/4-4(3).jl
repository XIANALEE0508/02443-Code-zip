using Random, Distributions, Printf, Statistics

function simulate_blocking_system_normal(seed::Int, m::Int, mean_service_time::Float64, total_customers::Int, std_dev::Float64)
    Random.seed!(seed)

    # Calculate rates
    arrival_rate = 1 / 1.0  # Mean interarrival time = 1

    # Simulate arrival times and service times
    arrival_times = cumsum(rand(Exponential(arrival_rate), total_customers))
    service_times = rand(Normal(mean_service_time, std_dev), total_customers)

    # Ensure no negative service times
    service_times = max.(service_times, 0.0)

    # Initialize service units
    servers = zeros(m)
    blocked_customers = 0  # Number of blocked customers

    # Simulation process
    for i in 1:total_customers
        # Check if there is an available service unit
        available_server = argmin(servers)
        if servers[available_server] <= arrival_times[i]
            # If there is an available service unit, assign it to the customer
            servers[available_server] = arrival_times[i] + service_times[i]
        else
            # If there is no available service unit, the customer is blocked
            blocked_customers += 1
        end
    end

    # Calculate blocking rate
    blocking_fraction = blocked_customers / total_customers

    # Calculate confidence interval
    alpha = 0.05
    z = quantile(Normal(0, 1), 1 - alpha / 2)
    conf_interval = blocking_fraction .+ [-1, 1] * z * sqrt(blocking_fraction * (1 - blocking_fraction) / total_customers)

    # Output results
    @printf("Normal Distribution (mean = %.2f, std dev = %.2f)\n", mean_service_time, std_dev)
    @printf("Number of blocked customers: %d\n", blocked_customers)
    @printf("Blocking fraction: %.5f\n", blocking_fraction)
    @printf("95%% confidence interval: [%.5f, %.5f]\n", conf_interval...)
end

# Run the simulations with different standard deviations
simulate_blocking_system_normal(123, 10, 8.0, 100000, 1.0)  # Example with std dev = 1.0
simulate_blocking_system_normal(123, 10, 8.0, 100000, 2.0)  # Example with std dev = 2.0
