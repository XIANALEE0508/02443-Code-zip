using Random, Distributions, Printf, Statistics

function simulate_blocking_system_hyperexp(seed::Int, m::Int, mean_service_time::Float64, total_customers::Int, p1::Float64, λ1::Float64, p2::Float64, λ2::Float64)
    Random.seed!(seed)

    # Calculate service rate
    service_rate = 1 / mean_service_time  # Service rate

    # Simulate arrival times and service times
    arrival_times = Vector{Float64}(undef, total_customers)
    for i in 1:total_customers
        if rand() < p1
            arrival_times[i] = rand(Exponential(λ1))
        else
            arrival_times[i] = rand(Exponential(λ2))
        end
    end
    arrival_times = cumsum(arrival_times)
    service_times = rand(Exponential(service_rate), total_customers)

    # Initialize service units
    servers = zeros(m)
    blocked_customers = 0  # Number of blocked customers

    # Simulation process
    for i in 1:total_customers
        # Check if there is an available service unit
        available_server = argmin(servers)
        if servers[available_server] <= arrival_times[i]
            # If there is an available service unit, assign it to the customer
            servers[available_server] = arrival_times[i] + service_times[i]
        else
            # If there is no available service unit, the customer is blocked
            blocked_customers += 1
        end
    end

    # Calculate blocking rate
    blocking_fraction = blocked_customers / total_customers

    # Calculate confidence interval
    alpha = 0.05
    z = quantile(Normal(0, 1), 1 - alpha / 2)
    conf_interval = blocking_fraction .+ [-1, 1] * z * sqrt(blocking_fraction * (1 - blocking_fraction) / total_customers)

    # Output results
    @printf("Hyperexponential Distribution\n")
    @printf("Number of blocked customers: %d\n", blocked_customers)
    @printf("Blocking fraction: %.5f\n", blocking_fraction)
    @printf("95%% confidence interval: [%.5f, %.5f]\n", conf_interval...)
end

simulate_blocking_system_hyperexp(123, 5, 8.0, 100000, 0.8, 0.8333, 0.2, 5.0)
