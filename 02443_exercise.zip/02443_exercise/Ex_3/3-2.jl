using Random
using Distributions
using Statistics
using Plots

# Function to generate samples from a Pareto distribution using the inverse transform method
function pareto_samples(k, β, n)
    U = rand(n)  # Generate n uniform random numbers in the interval (0, 1)
    return β * (U.^(-1/k))
end

# Function to calculate theoretical mean and variance of Pareto distribution
function pareto_theoretical_mean_variance(k, β)
    mean = if k > 1
        β * k / (k - 1)
    else
        NaN  # Mean is not defined for k <= 1
    end

    variance = if k > 2
        β^2 * k / ((k - 1)^2 * (k - 2))
    else
        NaN  # Variance is not defined for k <= 2
    end
    
    return mean, variance
end

# Parameters and number of samples
n = 10000
k_values = [2.05, 2.5, 3, 4]
β = 1.0

# Generate samples and calculate statistics
results = []

for k in k_values
    samples = pareto_samples(k, β, n)
    empirical_mean = mean(samples)
    empirical_variance = var(samples)
    theoretical_mean, theoretical_variance = pareto_theoretical_mean_variance(k, β)
    
    push!(results, (k, empirical_mean, empirical_variance, theoretical_mean, theoretical_variance))
    
    # Plot histogram and analytical PDF
    p = histogram(samples, bins=50, normalize=true, title="Pareto Distribution (k=$k)", xlabel="Value", ylabel="Frequency", label="Sampled Data")
    x_pareto = 1:0.1:maximum(samples)
    y_pareto = pdf.(Pareto(β, k), x_pareto)
    plot!(p, x_pareto, y_pareto, lw=2, label="Analytical PDF")
    display(p)
end

# Display results
using DataFrames
df = DataFrame(results, [:k, :EmpiricalMean, :EmpiricalVariance, :TheoreticalMean, :TheoreticalVariance])
display(df)
