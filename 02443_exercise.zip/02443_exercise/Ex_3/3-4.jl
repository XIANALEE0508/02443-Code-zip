using Random
using Distributions
using Statistics
using Plots

# Function to simulate from the Pareto distribution using composition
function pareto_samples_composition(μ, k, n)
    U = rand(n)  # Generate n uniform random numbers in the interval (0, 1)
    X = μ * (U.^(-1/k))
    return X
end

# Parameters and number of samples
n = 10000
μ = 1.0  # Scale parameter for Pareto distribution
k = 1.5  # Shape parameter for Pareto distribution

# Generate samples
pareto_samples_comp = pareto_samples_composition(μ, k, n)

# Theoretical mean and variance
theoretical_mean = μ * k / (k - 1)
theoretical_variance = (μ^2 * k) / ((k - 1)^2 * (k - 2))

# Empirical mean and variance
empirical_mean = mean(pareto_samples_comp)
empirical_variance = var(pareto_samples_comp)

println("Theoretical Mean: $theoretical_mean")
println("Empirical Mean: $empirical_mean")
println("Theoretical Variance: $theoretical_variance")
println("Empirical Variance: $empirical_variance")

# Plotting histogram and analytical PDF
p = histogram(pareto_samples_comp, bins=50, normalize=true, title="Pareto Distribution using Composition Method", xlabel="Value", ylabel="Frequency", label="Sampled Data")
x_pareto = range(μ, stop=maximum(pareto_samples_comp), length=100)
y_pareto = pdf.(Pareto(μ, k), x_pareto)
plot!(p, x_pareto, y_pareto, lw=2, label="Analytical PDF")

# Display plot
display(p)
