using Random
using Distributions
using Plots

# Function to generate samples from an Exponential distribution using the inverse transform method
function exponential_samples(lambda, n)
    U = rand(n)  # Generate n uniform random numbers in the interval (0, 1)
    return -log.(U) / lambda
end

# Function to generate samples from a Normal distribution using the Box-Muller transform
function box_muller_samples(n)
    u1 = rand(n)
    u2 = rand(n)
    z0 = sqrt.(-2 * log.(u1)) .* cos.(2 * pi * u2)
    z1 = sqrt.(-2 * log.(u1)) .* sin.(2 * pi * u2)
    return vcat(z0, z1)
end

# Function to generate samples from a Pareto distribution using the inverse transform method
function pareto_samples(k, β, n)
    U = rand(n)  # Generate n uniform random numbers in the interval (0, 1)
    return β * (U.^(-1/k))
end

# Parameters and number of samples
n = 10000
lambda = 1.0
mu = 0.0
sigma = 1.0
k_values = [2.05, 2.5, 3, 4]
β = 1.0

# Generate samples
exp_samples = exponential_samples(lambda, n)
norm_samples = mu .+ sigma .* box_muller_samples(n ÷ 2)  # Generating n normal samples (half from each z0 and z1)
pareto_samples_dict = Dict(k => pareto_samples(k, β, n) for k in k_values)

# Plotting histograms and comparing with analytical distributions

# Exponential distribution
p1 = histogram(exp_samples, bins=50, normalize=true, title="Exponential Distribution", xlabel="Value", ylabel="Frequency", label="Sampled Data")
x_exp = 0:0.1:maximum(exp_samples)
y_exp = pdf.(Exponential(lambda), x_exp)
plot!(p1, x_exp, y_exp, lw=2, label="Analytical PDF")

# Normal distribution
p2 = histogram(norm_samples, bins=50, normalize=true, title="Normal Distribution", xlabel="Value", ylabel="Frequency", label="Sampled Data")
x_norm = minimum(norm_samples):0.1:maximum(norm_samples)
y_norm = pdf.(Normal(mu, sigma), x_norm)
plot!(p2, x_norm, y_norm, lw=2, label="Analytical PDF")

# Pareto distributions for different k values
pareto_plots = []
for k in k_values
    p = histogram(pareto_samples_dict[k], bins=50, normalize=true, title="Pareto Distribution (k=$k)", xlabel="Value", ylabel="Frequency", label="Sampled Data")
    x_pareto = 1:0.1:maximum(pareto_samples_dict[k])
    y_pareto = pdf.(Pareto(β, k), x_pareto)
    plot!(p, x_pareto, y_pareto, lw=2, label="Analytical PDF")
    push!(pareto_plots, p)
end

# Display plots
display(p1)
display(p2)
for p in pareto_plots
    display(p)
end
