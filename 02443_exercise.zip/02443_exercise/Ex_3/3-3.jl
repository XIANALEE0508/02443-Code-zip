using Random
using Distributions
using Statistics
using DataFrames

# Function to generate confidence intervals for mean
function ci_mean(samples, confidence_level=0.95)
    n = length(samples)
    mean_val = mean(samples)
    std_err = std(samples) / sqrt(n)
    margin_of_error = quantile(Normal(0, 1), 1 - (1 - confidence_level) / 2) * std_err
    return (mean_val - margin_of_error, mean_val + margin_of_error)
end

# Function to generate confidence intervals for variance
function ci_variance(samples, confidence_level=0.95)
    n = length(samples)
    var_val = var(samples)
    chi2_lower = quantile(Chisq(n - 1), (1 - confidence_level) / 2)
    chi2_upper = quantile(Chisq(n - 1), 1 - (1 - confidence_level) / 2)
    lower_bound = (n - 1) * var_val / chi2_upper
    upper_bound = (n - 1) * var_val / chi2_lower
    return (lower_bound, upper_bound)
end

# Parameters
n_samples = 100
n_observations = 10
mu = 0.0
sigma = 1.0
confidence_level = 0.95

# Generate confidence intervals
results = []

for _ in 1:n_samples
    samples = rand(Normal(mu, sigma), n_observations)
    ci_mean_interval = ci_mean(samples, confidence_level)
    ci_variance_interval = ci_variance(samples, confidence_level)
    push!(results, (ci_mean_interval, ci_variance_interval))
end

# Convert results to DataFrame for display
mean_intervals = [r[1] for r in results]
variance_intervals = [r[2] for r in results]
df = DataFrame(
    MeanLower = [ci[1] for ci in mean_intervals],
    MeanUpper = [ci[2] for ci in mean_intervals],
    VarianceLower = [ci[1] for ci in variance_intervals],
    VarianceUpper = [ci[2] for ci in variance_intervals]
)

# Display results
display(df)

# Summary of results
mean_coverage = mean([mu >= ci[1] && mu <= ci[2] for ci in mean_intervals])
variance_coverage = mean([sigma^2 >= ci[1] && sigma^2 <= ci[2] for ci in variance_intervals])
println("Coverage probability for mean: $mean_coverage")
println("Coverage probability for variance: $variance_coverage")
